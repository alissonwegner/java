/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package farmacia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author alisson
 */
public class Conectbanco {

    private Connection con = null;

    public Connection getbanco(String user, String pass){

        String jdbcdriver = "com.mysql.jdbc.Driver";
        String DBUrl = "jdbc:mysql://localhost/farmacia?useTimezone=true&serverTimezone=UTC";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Connecting to database...");
            con = (Connection) DriverManager.getConnection(DBUrl, user, pass);
            return con;
        } catch (SQLException se) { 
            System.err.println(se);
            return null;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Conectbanco.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
        
    }
}
