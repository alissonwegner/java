/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package farmacia;

/**
 *
 * @author alisson
 */
       
public class Produto {
    public String nome;
    public String codigo;
    public double valor;
    public int quantidade;

    Produto(String nome, String codigo, int quantidade, double valor) {
        this.nome = nome;
        this.codigo = codigo;
        this.valor = valor;
        this.quantidade = quantidade;
    }
    
    public void Produto(){
        
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public String getNome() {
        return nome;
    }

    public String getCodigo() {
        return codigo;
    }

    public double getValor() {
        return valor;
    }

    public int getQuantidade() {
        return quantidade;
    }
        
    
}
