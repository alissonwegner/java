/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package farmacia;

/**
 *
 * @author alisson
 */
public class usuario{
                String nome;
        int id;
        String senha;
        String nome_completo;

    usuario(int id, String novonome, String senha, String nomecompleto) {
    }
    public void usuario(int id, String novonome, String senha, String nomecompleto){
     this.id = id;
     this.nome = novonome;
     this.senha = senha;
     this.nome_completo = nomecompleto;

    }
        public void usuario(){
   }

        public void setNome(String nome) {
            this.nome = nome;
        }

        public void setId(int id) {
            this.id = id;
        }

        public void setSenha(String senha) {
            this.senha = senha;
        }

        public void setNome_completo(String nome_completo) {
            this.nome_completo = nome_completo;
        }

        public String getNome() {
            return nome;
        }

        public int getId() {
            return id;
        }

        public String getSenha() {
            return senha;
        }

        public String getNome_completo() {
            return nome_completo;
        }
    }
    
   
